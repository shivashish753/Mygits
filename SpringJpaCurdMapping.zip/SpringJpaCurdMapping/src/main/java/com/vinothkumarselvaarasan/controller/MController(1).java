package com.vinothkumarselvaarasan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.vinothkumarselvaarasan.entity.YTVideos;
import com.vinothkumarselvaarasan.service.CommentService;
import com.vinothkumarselvaarasan.service.VideoService;

@Controller
@RequestMapping("/youtube")
public class MController {
	
	@Autowired
	VideoService videoService;
	
	@GetMapping("/YTVVideoList")
	public String videoList1(Model model)
	{
		List<YTVideos> ytvideosList=videoService.getVideoList();
		model.addAttribute("ytvideosList",ytvideosList);
		return "videoList";
	}
	@GetMapping("/CreateVideos")
	public String addVideo1(Model model)
	{
		model.addAttribute("YTVideos", new YTVideos());
		return "add_video";
	}
	
	@PostMapping("/CreateVideos/add")
	public String  addVideoFromForm(YTVideos ytVideos)
	{
		videoService.saveVideos(ytVideos);
		return "redirect:/youtube/YTVVideoList";
	}
	
	@GetMapping("/check")
	public String getCallfromUser()
	{
		return "Welcome Vinoth";
	}
	

}
