package com.vinothkumarselvaarasan.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="ytvComment")
public class YTVComments {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="commentsid")
	private int commentsId;
	
	@Column(name="userName")
	private String userName;
	
	@Column(name="comments")
	private String comments;
	
	@Temporal(TemporalType.DATE)
	@Column(name="hostDate")
	Date hostDate;
	
	@ManyToOne()
	@JoinColumn(name="video_id",referencedColumnName = "videoId	")
	private YTVideos ytVideos;
	
	
	

	public YTVComments() {
	}

	public YTVComments(int commentsId, String userName, String comments, Date hostDate) {
		this.commentsId = commentsId;
		this.userName = userName;
		this.comments = comments;
		this.hostDate = hostDate;
	}

	public int getCommentsId() {
		return commentsId;
	}

	public void setCommentsId(int commentsId) {
		this.commentsId = commentsId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public Date getHostDate() {
		return hostDate;
	}

	public void setHostDate(Date hostDate) {
		this.hostDate = hostDate;
	}
	

	public YTVideos getYtVideos() {
		return ytVideos;
	}

	public void setYtVideos(YTVideos ytVideos) {
		this.ytVideos = ytVideos;
	}

	
	
	
	
}
