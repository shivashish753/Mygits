package com.vinothkumarselvaarasan.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name="ytvideos")
public class YTVideos {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name="videoId")
	private int videoId;
	
	@Column(name="videoUrl")
	private String videoURL;
	
	@Column(name="channerlName")
	private String channelName;
	
	@Column(name="titleName")
	private String titleName;
	
	@Temporal(TemporalType.DATE)
	Date hostDate;
	
	

	public YTVideos() {
		
	}

	public YTVideos(int videoId, String videoURL, String channelName, String titleName, Date hostDate) {
		this.videoId = videoId;
		this.videoURL = videoURL;
		this.channelName = channelName;
		this.titleName = titleName;
		this.hostDate = hostDate;
	}

	public int getVideoId() {
		return videoId;
	}

	public void setVideoId(int videoId) {
		this.videoId = videoId;
	}

	public String getVideoURL() {
		return videoURL;
	}

	public void setVideoURL(String videoURL) {
		this.videoURL = videoURL;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public String getTitleName() {
		return titleName;
	}

	public void setTitleName(String titleName) {
		this.titleName = titleName;
	}

	public Date getHostDate() {
		return hostDate;
	}

	public void setHostDate(Date hostDate) {
		this.hostDate = hostDate;
	}
	
	
	
	
	

}
