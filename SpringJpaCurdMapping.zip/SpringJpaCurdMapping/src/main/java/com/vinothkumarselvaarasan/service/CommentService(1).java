package com.vinothkumarselvaarasan.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.vinothkumarselvaarasan.entity.YTVComments;
import com.vinothkumarselvaarasan.entity.YTVideos;
import com.vinothkumarselvaarasan.repository.CommentsRepository;

@Service
public class CommentService {

	@Autowired
	CommentsRepository commentsRepository;
	
	public void saveComments(YTVComments ytvComments) {
		commentsRepository.save(ytvComments);
	}

	

}
