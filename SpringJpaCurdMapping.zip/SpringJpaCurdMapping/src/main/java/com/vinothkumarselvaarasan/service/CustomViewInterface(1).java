package com.vinothkumarselvaarasan.service;

public interface CustomViewInterface {

//	String getChannerlName();
//	String getTitleName();
	String getComments();
}
