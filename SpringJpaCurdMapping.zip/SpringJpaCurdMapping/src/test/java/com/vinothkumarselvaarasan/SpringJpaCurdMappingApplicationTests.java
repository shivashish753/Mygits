package com.vinothkumarselvaarasan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaCurdMappingApplicationTests {

	@Test
	void contextLoads() {
	}

}
