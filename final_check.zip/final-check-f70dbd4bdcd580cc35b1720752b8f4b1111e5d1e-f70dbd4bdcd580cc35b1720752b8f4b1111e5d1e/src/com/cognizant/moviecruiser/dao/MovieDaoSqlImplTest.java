package com.cognizant.moviecruiser.dao;

public class MovieDaoSqlImplTest {

	public static void main(String[] args) {

	}

	public static void testGetMovieListAdmin() {

	}

	public static void testGetMovieListCustomer() {

	}

	public static void testModifyMovie() {

	}

	public static void testGetMovie() {

	}
}
