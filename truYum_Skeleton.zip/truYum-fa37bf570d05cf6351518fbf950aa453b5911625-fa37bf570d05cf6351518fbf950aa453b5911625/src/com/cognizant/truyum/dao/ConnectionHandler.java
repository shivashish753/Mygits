package com.cognizant.truyum.dao;

public class ConnectionHandler {
//	public static Connection getConnection() {
//	  
//	}
//	 

}
